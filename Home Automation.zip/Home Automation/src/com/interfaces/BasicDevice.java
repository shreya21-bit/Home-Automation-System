package com.interfaces;

public interface BasicDevice 
{

	boolean turnOn();
	boolean turnOff();
	long checkTime();
}
