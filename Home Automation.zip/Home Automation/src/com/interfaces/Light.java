
package com.interfaces;

public interface Light 
{

	void dim(int level);
}

