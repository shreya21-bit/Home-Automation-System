
package com.interfaces;

public interface TempControllable 
{

	void setTemperature(int temp);
}
