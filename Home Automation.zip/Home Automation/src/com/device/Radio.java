package com.device;

import com.interfaces.MediaDevice;

public class Radio extends Device implements MediaDevice
{

	@Override
	public void play() 
	{
		// TODO Auto-generated method stub
		
	}

	public Radio()
	{
		super();
		System.out.println("\tRadio Obj Created");
	}

	@Override
	public void pause() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void next() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void previous() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void adjustVolume() 
	{
		// TODO Auto-generated method stub
		
	}
}
