package com.device;

import com.interfaces.Light;

public class Lights extends Device implements Light
{

	
	public void dim(int level) 
	{
		// TODO Auto-generated method stub
		
	}

	public Lights() {
		super();
		System.out.println("\tLights object created");
	}	
}
